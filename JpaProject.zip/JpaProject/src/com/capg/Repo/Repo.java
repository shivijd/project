package com.capg.Repo;

import java.math.BigDecimal;

import com.capg.beans.Customer;

//import com.capg.exce.InvalidPhoneNumberException;
//import com.capgemini.beans.Customer;

public interface Repo {
	 boolean save(Customer customer);		
	public Customer findByOne(String mobileNo) ;
	public boolean update(String mobileNo,BigDecimal balance);
//	public boolean remove(Customer customer);
	//public boolean updateTransaction(int id,String mobileNo,String Type,BigDecimal balance);
}
