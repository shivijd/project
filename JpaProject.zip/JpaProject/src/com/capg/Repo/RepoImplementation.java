package com.capg.Repo;

import java.math.BigDecimal;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capg.beans.Customer;
public class RepoImplementation implements Repo {
	static  EntityManagerFactory factory;
	static  EntityManager entityManager;
	static  EntityTransaction entra;
	public RepoImplementation()
	{
		factory=Persistence.createEntityManagerFactory("emp");
		entityManager=factory.createEntityManager();
		entra=entityManager.getTransaction();
	}
	@Override
	public boolean save(Customer customer) {
try {
			
			Customer c = findByOne(customer.getMobileNo());
			
			if(c == null) {
				
				entityManager.getTransaction( ).begin();
				entityManager.persist(customer);
				entityManager.getTransaction().commit();
				return true;
			}
			else { 
				return false;
			}
		}
		catch (Exception e) {
			
			System.out.println("Exception in creating Account Method");
		}
		return true;
	}
	@Override
	public Customer findByOne(String mobileNo) {
		try
		{
	Customer cust=entityManager.find(Customer.class,mobileNo);	
	if(cust!= null) 
	   return cust;
		}
	catch(Exception e)
	{
		System.out.println("Mobile Number Not Found");
	}
		return null;
	}
	@Override
	public boolean update(String mobileNo, BigDecimal balance) {
		entra.begin();
		Customer cust=entityManager.find(Customer.class, mobileNo);
				cust.getWallet().setBalance(balance);
				entityManager.persist(cust);
				entra.commit();
		return false;
	
	}
	}


//	@Override
//	public boolean updateTransaction(int id, String mobileNo, String Type, BigDecimal balance) {
//		
//		return false;
//	}

