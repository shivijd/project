package com.capg.mains;

import java.math.BigDecimal;

import com.capg.Repo.Repo;
import com.capg.Repo.RepoImplementation;
import com.capg.exceptn.InvalidAmountPresentException;
import com.capg.exceptn.InvalidPhoneNumberException;
import com.capg.exceptn.MobileNumberAlreadyExistException;
import com.capg.service.ServiceLayer;
import com.capg.service.ServiceLayerImple;
public class MainPersist {

	public static void main(String[] args) throws InvalidAmountPresentException, InvalidPhoneNumberException, MobileNumberAlreadyExistException  {
		Repo wal=new RepoImplementation();
		ServiceLayer walS=new ServiceLayerImple(wal);			
		walS.createAccount("9198268281", "sarita", new BigDecimal("10000.09"));
		walS.createAccount("7500725707", "shivi", new BigDecimal("50000.0"));
		 walS.depositAmount( "9198268281", new BigDecimal("1000"));
		
	}
	}
