package com.capg.service;

import java.math.BigDecimal;

import com.capg.beans.Customer;
import com.capg.exceptn.InvalidAmountPresentException;
import com.capg.exceptn.InvalidPhoneNumberException;
import com.capg.exceptn.MobileNumberAlreadyExistException;
public interface ServiceLayer {
	public Customer createAccount(String mobileNumber, String name, BigDecimal initialBalance) throws MobileNumberAlreadyExistException;
	public Customer showBalance(String mobileNo) throws InvalidPhoneNumberException ;
    public Customer depositAmount(String mobileNo,BigDecimal Amount) throws InvalidPhoneNumberException ;
    public Customer withdrawAmount(String mobileNo,BigDecimal Amount) throws InvalidAmountPresentException, InvalidPhoneNumberException ;
   public boolean validAmount(BigDecimal Amount) throws InvalidAmountPresentException;
    public Customer fundTransfer(String sourceMobNo,String Target,BigDecimal Amount);
	boolean repeatedAcc(String mobileNo) throws MobileNumberAlreadyExistException;
}
