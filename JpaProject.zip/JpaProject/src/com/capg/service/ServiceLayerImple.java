package com.capg.service;

import java.math.BigDecimal;

import com.capg.Repo.Repo;
import com.capg.beans.Customer;
import com.capg.beans.Wallet;
import com.capg.exceptn.InvalidAmountPresentException;
import com.capg.exceptn.InvalidPhoneNumberException;
import com.capg.exceptn.MobileNumberAlreadyExistException;
public class ServiceLayerImple implements ServiceLayer{
	
		static int count=1;
		Repo wa ;
		public ServiceLayerImple(Repo wa2) {
		super();
		this.wa=wa2;
		}

		@Override
		public Customer createAccount(String mobileNo, String name, BigDecimal initialBalance) throws MobileNumberAlreadyExistException {
			Wallet wallet = new Wallet();
			wallet.setBalance(initialBalance);
			
			Customer customer = new Customer();
			customer.setMobileNo(mobileNo);
			customer.setName(name);
			customer.setWallet(wallet);
			
			if(wa.save(customer)) {
				return customer;
			}
			else {
				throw new MobileNumberAlreadyExistException();
			}
		}

		public Customer showBalance(String mobileNo) throws InvalidPhoneNumberException {
			Customer customer=wa.findByOne(mobileNo);
			if(customer == null) {
				throw new InvalidPhoneNumberException();
			}
			wa.update(mobileNo, customer.getWallet().getBalance());						
			return customer;
		}

		@Override
		public Customer depositAmount(String mobileNo, BigDecimal Amount)throws InvalidPhoneNumberException {
			Customer customer=wa.findByOne(mobileNo);
			if(customer == null) {
				throw new InvalidPhoneNumberException();
			}
		customer.getWallet().setBalance(customer.getWallet().getBalance().add(Amount));
		wa.update(mobileNo, customer.getWallet().getBalance());
		
			return customer;
		}

		@Override
		public Customer withdrawAmount(String mobileNo, BigDecimal Amount) throws InvalidAmountPresentException,InvalidPhoneNumberException{
			if(validAmount(Amount))
				throw new InvalidAmountPresentException();
			Customer customer=wa.findByOne(mobileNo);
			if(customer == null) {
				throw new InvalidPhoneNumberException();
			}
			customer.getWallet().setBalance(customer.getWallet().getBalance().subtract(Amount));
			wa.update(mobileNo, customer.getWallet().getBalance());
			
			return customer;
		}

		@Override
		public Customer fundTransfer(String sourceMobNo, String Target, BigDecimal Amount) {
			Customer customer=wa.findByOne(sourceMobNo);
			Customer customer1=wa.findByOne(Target);
			customer1.getWallet().setBalance(customer1.getWallet().getBalance().add(Amount));
			
			//FUND GET RECIEVED TO OTHER ACCOUNT
			
			customer1.getWallet().setBalance(customer.getWallet().getBalance().subtract(Amount));
			wa.update(Target,customer.getWallet().getBalance());
			//FUND TRANSFER FROM FIRST ACCOUNT
			return customer1;
		}

		@Override
	public boolean validAmount(BigDecimal Amount)throws InvalidAmountPresentException
	{
		// if(!((c.getWallet().getBalance().compareTo(BigDecimal.ZERO)>0)))
		if(!(Amount.compareTo(BigDecimal.ZERO)>0))
				   throw new InvalidAmountPresentException();
		 return false;
	}
@Override
		public boolean repeatedAcc(String mobileNo)throws MobileNumberAlreadyExistException
		{
			Customer temp=null;
			temp=wa.findByOne(mobileNo);
			if(temp!=null)
			throw new MobileNumberAlreadyExistException();
			return true;
					
		}



	
	}


