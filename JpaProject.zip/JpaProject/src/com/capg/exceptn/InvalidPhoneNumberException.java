package com.capg.exceptn;

public class InvalidPhoneNumberException extends Exception {
	public InvalidPhoneNumberException()
	{
		System.out.println("invalid phone number");
	}
}
