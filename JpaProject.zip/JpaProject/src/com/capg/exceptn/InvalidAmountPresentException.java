package com.capg.exceptn;

public class InvalidAmountPresentException extends Exception {
public	InvalidAmountPresentException()
{
	System.out.println("Invalid amount");
}
}
