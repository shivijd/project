package com.capg.exceptn;

public class MobileNumberAlreadyExistException extends Exception {
	public MobileNumberAlreadyExistException()
	{
		System.out.println("already exist");
	}
}
