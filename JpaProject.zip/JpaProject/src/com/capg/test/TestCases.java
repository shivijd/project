package com.capg.test;
import static org.junit.Assert.assertEquals;
import java.math.BigDecimal;
import org.junit.Before;
import org.junit.Test;
import com.capg.Repo.RepoImplementation;
import com.capg.beans.Customer;
import com.capg.beans.Wallet;
import com.capg.exceptn.InvalidAmountPresentException;
import com.capg.exceptn.InvalidPhoneNumberException;
import com.capg.exceptn.MobileNumberAlreadyExistException;
import com.capg.service.ServiceLayer;
import com.capg.service.ServiceLayerImple;


public class TestCases {

	ServiceLayer service;

	@Before
	public void setup() {
		service = new ServiceLayerImple(new RepoImplementation());
		
		
	}
	
	
	/*
	 *   Test Cases for Creating Customer Account
	 * 1. When Valid Information Passed Customer Account Will be Created
	 * 2. when an Account is Already exist it will throw DuplicateIdentityException
	 */
	
	@Test
	public void whenCustomerObjectCreatedSuccessfully() throws InvalidPhoneNumberException, MobileNumberAlreadyExistException{
		
		Wallet wallet = new Wallet();
		wallet.setBalance(new BigDecimal("123.12"));
		
		Customer customer1 = new Customer();
		customer1.setMobileNo("9927999980");
		customer1.setName("Shivi");
		customer1.setWallet(wallet);
	
		Customer customer = service.createAccount("9927999980", "Shivi", new BigDecimal("123.12"));
		
		assertEquals(customer1, customer);
	}
	
	@Test(expected = MobileNumberAlreadyExistException.class)
	public void whenCustomerPassesPhoneNumberToCreateCustomerAccountButPhoneNumberAlreadyExist() throws MobileNumberAlreadyExistException {
		service.createAccount("9999999981", "shivi", new BigDecimal("200.12"));
		service.createAccount("9999999981", "shikha", new BigDecimal("208.12"));
	}
	
	/*
	 * 	Test Cases for show Balance
	 * 1. When the valid information is passed
	 * 2. when account is not present with that Id
	 */
	@Test
	public void whenCustomerWantsToSeeHisBalanceWithValidInformation() throws MobileNumberAlreadyExistException, InvalidPhoneNumberException {
		
		assertEquals(service.createAccount("9198268281", "Shivi", new BigDecimal("124.12")), service.showBalance("91918268281"));
	}

	@Test(expected = InvalidPhoneNumberException.class)
	public void whenCustomerWantsToSeeHisBalanceWhenMobileNumberIsdoesnotExist() throws InvalidPhoneNumberException, MobileNumberAlreadyExistException {
		
		assertEquals(service.createAccount("9198268282", "shivi ", new BigDecimal("123.12")), service.showBalance("9198268281"));
	}
	
	
	/*
	 * 	Test Cases for deposit Balance
	 * 1. when Valid Information is passed it should deposit balance
	 * 2. when Id is not Exist and try to deposit balance, it will throw IdNotExistException
	 */
	@Test
	public void whenCustomerWantsToDepositHisBalanceWithValidInformation() throws MobileNumberAlreadyExistException, InvalidPhoneNumberException{
		service.createAccount("9191268281", "shivi", new BigDecimal("123.12"));
		
		Wallet wallet = new Wallet();
		wallet.setBalance(new BigDecimal("123.12"));
		
		Customer customer1 = new Customer();
		customer1.setMobileNo("9198268281");
		customer1.setName("shivi");
		customer1.setWallet(wallet);
		
		assertEquals(customer1, service.depositAmount("9198268281", new BigDecimal("100")));
	}

	@Test(expected = InvalidPhoneNumberException.class)
	public void whenCustomerWantsToDepositHisBalanceWithInValidInformation() throws InvalidPhoneNumberException, MobileNumberAlreadyExistException {
		
		service.createAccount("7500725707", "shivi", new BigDecimal("123.12"));
				service.depositAmount("7500725707", new BigDecimal("100.66"));	
	}
	
	/*
	 * 	Test Cases for withdraw Balance
	 * 1. When Valid Information is passed it should withdraw balance
	 * 2. When Id is not Exist and try to withdraw balance, it will throw IdNotExistException
	 * 3. When Customer Account have Lower Balance then withdraw Amount it will throw InsufficientWalletBalanceException
	 */
	@Test(expected = MobileNumberAlreadyExistException.class)
	public void whenCustomerWantsToWithdrawHisBalanceWithValidInformation() throws MobileNumberAlreadyExistException,InvalidPhoneNumberException,InvalidAmountPresentException {
		service.createAccount("9198268281", "shivi", new BigDecimal("123.12"));
		

		Wallet wallet = new Wallet();
		wallet.setBalance(new BigDecimal("123.12"));
		
		Customer customer1 = new Customer();
		customer1.setMobileNo("9198268281");
		customer1.setName("shivi");
		customer1.setWallet(wallet);
		
		assertEquals(customer1, service.withdrawAmount("9198268281", new BigDecimal(100)));
	}

	@Test(expected = InvalidPhoneNumberException.class)
	public void whenCustomerWantsToWithdrawHisBalanceWithInValidInformation() throws MobileNumberAlreadyExistException,InvalidPhoneNumberException,InvalidAmountPresentException {
		
		assertEquals(service.createAccount("9198268281", "shivi", new BigDecimal("123.12")),
				service.withdrawAmount("9198269291", new BigDecimal("10.00")));
	}
	
	@Test(expected = InvalidAmountPresentException.class)
	public void whenCustomerWantsToWithdrawHisBalanceWhenBalanceIsLessThanWithdrawBalance() throws InvalidAmountPresentException,MobileNumberAlreadyExistException, InvalidPhoneNumberException {
		
		assertEquals(service.createAccount("9198268281", "shivi", new BigDecimal("123.12")),
				service.withdrawAmount("9198268281", new BigDecimal("1001.0")));
	}
	
	


}