package com.capgemini.Service;
import java.math.BigDecimal;
import com.capg.exce.InvalidAmountPresentException;
import com.capg.exce.InvalidPhoneNumberException;
import com.capgemini.beans.Customer;
import com.capgemini.repo.WalletRepo;
	
	public class WalletServiceImplementation implements WalletService {
		static int count=1;
		WalletRepo wa ;
		public WalletServiceImplementation(WalletRepo wa2) {
		super();
		this.wa=wa2;
		}


		public Customer showBalance(String mobileNo) throws InvalidPhoneNumberException {
			Customer customer=wa.findByOne(mobileNo);
			wa.update(mobileNo, customer.getWallet().getBalance());						
			wa.updateTransaction(count++, mobileNo,"show bALANCE", customer.getWallet().getBalance());
			return customer;
		}

		@Override
		public Customer depositAmount(String mobileNo, BigDecimal Amount)throws InvalidPhoneNumberException {
			Customer customer=wa.findByOne(mobileNo);
			if(customer==null)
				throw new InvalidPhoneNumberException();
		customer.getWallet().setBalance(customer.getWallet().getBalance().add(Amount));
		wa.update(mobileNo, customer.getWallet().getBalance());
		
		wa.updateTransaction(count++, mobileNo,"Deposit", customer.getWallet().getBalance());
			return customer;
		}

		@Override
		public Customer withdrawAmount(String mobileNo, BigDecimal Amount)throws InvalidAmountPresentException,InvalidPhoneNumberException {
			if(validAmount(Amount))
				throw new InvalidAmountPresentException();
			
			Customer customer=wa.findByOne(mobileNo);
		
			customer.getWallet().setBalance(customer.getWallet().getBalance().subtract(Amount));
			wa.update(mobileNo, customer.getWallet().getBalance());
			
			wa.updateTransaction(count++, mobileNo,"Withdraw", customer.getWallet().getBalance());
			return customer;
		}

		@Override
		public Customer fundTransfer(String sourceMobNo, String Target, BigDecimal Amount) throws InvalidPhoneNumberException {
			Customer customer=wa.findByOne(sourceMobNo);
			Customer customer1=wa.findByOne(Target);
			customer1.getWallet().setBalance(customer1.getWallet().getBalance().add(Amount));
			
			//FUND GET RECIEVED TO OTHER ACCOUNT
			
			customer1.getWallet().setBalance(customer.getWallet().getBalance().subtract(Amount));
			wa.update(Target,customer.getWallet().getBalance());
			wa.updateTransaction(count++, Target,"FundTransfer", customer.getWallet().getBalance());
			//FUND TRANSFER FROM FIRST ACCOUNT
			return customer1;
		}
		
				
	
		@Override
	public boolean validAmount(BigDecimal Amount)throws InvalidAmountPresentException
	{
		// if(!((c.getWallet().getBalance().compareTo(BigDecimal.ZERO)>0)))
		if(!(Amount.compareTo(BigDecimal.ZERO)>0))
				   throw new InvalidAmountPresentException();
		 return false;
	}


	

	
	}

