package com.capgemini.Service;
import java.math.BigDecimal;
import com.capg.exce.InvalidAmountPresentException;
import com.capg.exce.InvalidPhoneNumberException;
import com.capgemini.beans.Customer;

public interface WalletService {
   //   public Customer createAccount(String name,String mobileNo,BigDecimal Amount) throws InvalidPhoneNumberException, InvalidNameException,InvalidAmountPresentException, MobileNumberAlreadyExistException;
        public Customer showBalance(String mobileNo) throws InvalidPhoneNumberException;
        public Customer depositAmount(String mobileNo,BigDecimal Amount) throws InvalidPhoneNumberException;
        public Customer withdrawAmount(String mobileNo,BigDecimal Amount) throws InvalidAmountPresentException, InvalidPhoneNumberException;
        public boolean validAmount(BigDecimal Amount) throws InvalidAmountPresentException;
        public Customer fundTransfer(String sourceMobNo,String Target,BigDecimal Amount) throws InvalidPhoneNumberException;
       
}
