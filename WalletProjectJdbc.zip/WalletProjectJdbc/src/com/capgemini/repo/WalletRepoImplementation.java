package com.capgemini.repo;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capg.MakeConnection.ConnectC;
import com.capg.exce.InvalidPhoneNumberException;
import com.capgemini.beans.Customer;
import com.capgemini.beans.Wallet;
	public class WalletRepoImplementation implements WalletRepo {
		static Connection con=ConnectC.getConnection();
		static PreparedStatement pMobileNo;
		static PreparedStatement GetAll;
		 static PreparedStatement Wallet;
		 static PreparedStatement UpdateTransaction;
		 static PreparedStatement Update;
		
	 public  WalletRepoImplementation()
	 {
		try {
	
		 pMobileNo=con.prepareStatement("SELECT mobileNo from Amount2 where mobileNo=?");
		 GetAll=con.prepareStatement("SELECT * FROM Amount3 where MOBILENO=?");
		 UpdateTransaction=con.prepareStatement("INSERT INTO Transaction (id,MobileNo,type,balance)VALUES(?,?,?,?)");
		 Update=con.prepareStatement("UPDATE Amount3 set balance=? where mobileNo=?");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	 }
//	@Override
//	public boolean save(Customer c) throws MobileNumberAlreadyExistException  {
//	try {
//		pMobileNo.setString(1, c.getMobileNo());
//		ResultSet rs=pMobileNo.executeQuery();
//		if(rs.next())
//			if(rs.getString(1).equals(c.getMobileNo()))
//				throw new MobileNumberAlreadyExistException();	
//	} catch (SQLException e) {		
//		e.printStackTrace();
//	}
//	try {
//		Wallet.setString(1, c.getMobileNo());
//		Wallet.setString(2, c.getName());
//		Wallet.setInt(3, c.getWallet().getBalance().intValue());
//	} catch (SQLException e) {
//		
//		e.printStackTrace();
//	}
//		return false;
//	}
	@Override
	public Customer findByOne(String mobileNo) throws InvalidPhoneNumberException {
		Customer cust=new Customer();
		Wallet wall=new Wallet();
		
		System.out.println();
		try {
			GetAll.setString(1, mobileNo);
			ResultSet result=GetAll.executeQuery();
				if(result.next())
				{
					
					cust.setMobileNo(result.getString(1));
					cust.setName(result.getString(2));
					wall.setBalance(result.getBigDecimal(3));
					cust.setWallet(wall);
				
				}
			
	
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	
		return cust;
		
	}
	@Override
	public boolean update(String mobileNo,BigDecimal balance) {
		try {
			
			Update.setInt(1,balance.intValue());
			Update.setString(2, mobileNo);
			Update.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

public boolean updateTransaction(int id,String mobileNo,String Type,BigDecimal balance)
{
	try {
		UpdateTransaction.setInt(1, id);
		UpdateTransaction.setString(2, mobileNo);
		UpdateTransaction.setString(3, Type);
		UpdateTransaction.setInt(4, balance.intValue());		
		UpdateTransaction.executeQuery();
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
	return false;
	
}
	}

