package com.capg.exce;

public class InvalidPhoneNumberException extends Exception {

}
