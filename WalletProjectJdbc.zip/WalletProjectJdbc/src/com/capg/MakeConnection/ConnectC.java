package com.capg.MakeConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectC {
	
		public  static Connection getConnection() {
			Connection conn;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
		} catch (ClassNotFoundException e) {
		System.out.println("Class Not Found");
		
		}
	try {	
	 conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Capgemini123");
	 return conn;
	}
		 catch (SQLException e) {		
		e.printStackTrace();
	}
	return null;
	}
}
