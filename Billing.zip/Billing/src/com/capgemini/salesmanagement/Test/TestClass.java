package com.capgemini.salesmanagement.Test;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.salesmanagement.Exception.InvalidProductNameException;
import com.capgemini.salesmanagement.Service.ISaleService;
import com.capgemini.salesmanagement.Service.SaleServiceImplementation;
import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.ISaleDao;
import com.capgemini.salesmanagement.dao.SaleDaoImplementation;

public class TestClass {
  ISaleService isale;
	@Before
	public void setUp() throws Exception {
		ISaleDao is=new SaleDaoImplementation();
			ISaleService Dao=new SaleServiceImplementation(is);
	}

	@Test(expected=com.capgemini.salesmanagement.Exception.InvalidQuantityException.class)
	public void test()throws InvalidProductNameException {
		Sale sale=new Sale(1001, null, "Box", 2, 214, 467);	
		
	}
		
	}

