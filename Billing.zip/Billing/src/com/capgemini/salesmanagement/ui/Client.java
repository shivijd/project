package com.capgemini.salesmanagement.ui;

import java.util.Scanner;

import com.capgemini.salesmanagement.Exception.InsufficientPriceException;
import com.capgemini.salesmanagement.Exception.InvalidProductIdException;
import com.capgemini.salesmanagement.Exception.InvalidQuantityException;
import com.capgemini.salesmanagement.Service.ISaleService;
import com.capgemini.salesmanagement.Service.SaleServiceImplementation;
import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.ISaleDao;
import com.capgemini.salesmanagement.dao.SaleDaoImplementation;

public class Client {
	public static void main(String[]args) throws InvalidQuantityException, InsufficientPriceException, InvalidProductIdException
	{
Scanner scanner=new Scanner(System.in);
ISaleDao isale=new SaleDaoImplementation();
ISaleService iservice=new SaleServiceImplementation(isale);
//Generating Random ProductId
int prodId=(int) (Math.random()*(100));
System.out.println(prodId);

//Taking Input for ProductCode with Scanner
int prodCode=scanner.nextInt();
//Taking Input for ProductName with Scanner
String productName=scanner.next();
//Taking Input for ProductCategory with Scanner
String category=scanner.next();
//Taking Input for quantity with Scanner
int quantity=scanner.nextInt();
//Taking Input for ProductCode with Scanner
int price=scanner.nextInt();
//Calculating LineTotal using calculateMethod From Service Layer
float lineTotal=iservice.calculate(price, quantity);

System.out.println(iservice.insertSalesDetails(new Sale(prodCode, productName, category, quantity, lineTotal, price)));
scanner.close();
}
}