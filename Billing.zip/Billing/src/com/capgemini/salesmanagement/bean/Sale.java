package com.capgemini.salesmanagement.bean;

public class Sale {
private int saleId;
private int productCode;
private String productName;
private String category;
private int quantity;
private float lineTotal;
private float price;
public int getSaleId() {
	return saleId;
}
public float getPrice() {
	return price;
}
public void setPrice(float price) {
	this.price = price;
}
public void setSaleId(int saleId) {
	this.saleId = saleId;
}
public Sale( int productCode, String productName, String category, int quantity, float lineTotal,float price) {
	super();
	//this.saleId = saleId;
	this.productCode = productCode;
	this.productName = productName;
	this.category = category;
	this.quantity = quantity;
	this.lineTotal = lineTotal;
	this.price=price;
}
@Override
public String toString() {
	return "Sale [saleId=" + saleId + ", productCode=" + productCode + ", productName=" + productName + ", category="
			+ category + ", quantity=" + quantity + ", lineTotal=" + lineTotal + ", price=" + price + "]";
}
public int getProductCode() {
	return productCode;
}
public void setProductCode(int productCode) {
	this.productCode = productCode;
}
public String getProductName() {
	return productName;
}
public void setProductName(String productName) {
	this.productName = productName;
}
public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public float getLineTotal() {
	return lineTotal;
}
public void setLineTotal(float lineTotal) {
	this.lineTotal = lineTotal;
}
}
