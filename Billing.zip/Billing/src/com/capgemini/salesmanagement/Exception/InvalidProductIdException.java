package com.capgemini.salesmanagement.Exception;

public class InvalidProductIdException extends Exception {

}
