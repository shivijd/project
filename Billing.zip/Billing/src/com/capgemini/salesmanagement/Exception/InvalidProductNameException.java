package com.capgemini.salesmanagement.Exception;

public class InvalidProductNameException extends Exception {

}
