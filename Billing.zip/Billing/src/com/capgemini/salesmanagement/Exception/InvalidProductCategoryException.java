package com.capgemini.salesmanagement.Exception;

public class InvalidProductCategoryException extends Exception {

}
