package com.capgemini.salesmanagement.Exception;

public class InsufficientPriceException extends Exception {

}
