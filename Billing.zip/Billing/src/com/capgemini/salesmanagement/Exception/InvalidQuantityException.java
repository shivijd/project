package com.capgemini.salesmanagement.Exception;

public class InvalidQuantityException extends Exception {

}
