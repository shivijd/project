package com.capgemini.salesmanagement.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.capgemini.salesmanagement.bean.Sale;

public class SaleDaoImplementation implements ISaleDao {
	Map<Integer,Sale> map =new HashMap<>();

	//Checking for unique Id
//	@Override
//	public boolean save(Sale sale) {
//		if(map.containsKey(sale.getSaleId()))
//			return false;
//		else
//		map.put(sale.getSaleId(), sale);
//		return true;
//	}
	//First Search compare with key and then getting details or values from HashMap
	@Override
	public Sale insertSaleDetails (Sale sale) {
//		for(Entry<Integer,Sale> entry:map.entrySet())
//			if (entry.getKey().equals(sale.getSaleId()))
//			 return entry.getValue();
//		return null;
		
		map.put(sale.getSaleId(), sale);
		return sale;
	}
 
}