package com.capgemini.salesmanagement.dao;

import java.util.Map;

import com.capgemini.salesmanagement.bean.Sale;

public interface ISaleDao {
	//public boolean save(Sale sale);
	Sale  insertSaleDetails(Sale sale);
	

}
