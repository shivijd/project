package com.capgemini.salesmanagement.Service;

import com.capgemini.salesmanagement.Exception.InsufficientPriceException;
import com.capgemini.salesmanagement.Exception.InvalidProductCategoryException;
import com.capgemini.salesmanagement.Exception.InvalidProductIdException;
import com.capgemini.salesmanagement.Exception.InvalidProductNameException;
import com.capgemini.salesmanagement.Exception.InvalidQuantityException;
import com.capgemini.salesmanagement.bean.Sale;

public interface ISaleService {
public Sale insertSalesDetails(Sale sale) throws InvalidProductIdException;
public boolean validProductCode(int productId) throws InvalidProductIdException;
boolean validateQuantity(int qty) throws InvalidQuantityException;
public boolean validateProductCat(String prodCat) throws InvalidProductCategoryException;
public boolean validateProductName(String prodName) throws InvalidProductNameException;
public boolean validProductPrice(float price) throws InsufficientPriceException;
public float calculate(float price,int qty) throws InvalidQuantityException, InsufficientPriceException;



}
