package com.capgemini.salesmanagement.Service;
import com.capgemini.salesmanagement.Exception.InsufficientPriceException;
import com.capgemini.salesmanagement.Exception.InvalidProductCategoryException;
import com.capgemini.salesmanagement.Exception.InvalidProductIdException;
import com.capgemini.salesmanagement.Exception.InvalidProductNameException;
import com.capgemini.salesmanagement.Exception.InvalidQuantityException;
import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.ISaleDao;

public class SaleServiceImplementation implements ISaleService{

public SaleServiceImplementation(ISaleDao isale) {
		super();
		this.saleDao = isale;
	}

ISaleDao saleDao;
	@Override
	//Inserting Deatails Using HashMap
	public Sale insertSalesDetails(Sale sale) throws InvalidProductIdException {
	Sale s=new Sale(sale.getSaleId(),sale.getCategory(),sale.getProductName(),sale.getProductCode(),sale.getLineTotal(),sale.getPrice());
	if(validProductCode(sale.getProductCode()))			
//if(saleDao.save(sale))		
		return  saleDao.insertSaleDetails(sale);		
		//return null;
	return null;
	}

	@Override
	public boolean validProductCode(int productId) throws InvalidProductIdException {
		if(!(productId==1001)||(productId==1002)||(productId==1003)||(productId==1004))
			throw new InvalidProductIdException();
		return true;
	}
//validation of quantity
	@Override
	public boolean validateQuantity(int qty) throws InvalidQuantityException {	
		if(!(qty>2 && qty<5))
			throw new InvalidQuantityException();		
		return true;
	}
//validation of productCategory
	@Override
	public boolean validateProductCat(String prodCat) throws InvalidProductCategoryException {
		if(!(prodCat.equals("Electronics") ||prodCat.equals("Toys")))
              throw new InvalidProductCategoryException();
		return true;
		
	}
//Validation of productName
	@Override
	public boolean validateProductName(String prodName)throws InvalidProductNameException {
		if(!( prodName.equals("TV")||prodName.equals("Smart Phone")||prodName.equals("iphone")||prodName.equals("Soft Toy" )||prodName.equals("telescope")||prodName.equals("Barbie Doll")))
				throw new InvalidProductNameException();
		return true;
	}
//Validate Product PRICE
	@Override
	public boolean validProductPrice(float price) throws InsufficientPriceException {
		if(!(price>200))
			throw new InsufficientPriceException();
		return true;
	}
//Calculate LinePrice
	@Override
	public float calculate(float price, int qty) throws InvalidQuantityException, InsufficientPriceException {
	
		if(validateQuantity(qty) && validProductPrice(price) )
			return price*qty;
		return 0;
		
		
	}
	

}
