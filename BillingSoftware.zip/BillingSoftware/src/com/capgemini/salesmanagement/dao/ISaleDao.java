package com.capgemini.salesmanagement.dao;

import java.util.HashMap;

import com.capgemini.bean.Sale;

public interface ISaleDao {
public HashMap<Integer,Sale> insertDetails(Sale sale);
//public Sale searchById(int SaleId);
boolean save(Sale sale);

}
