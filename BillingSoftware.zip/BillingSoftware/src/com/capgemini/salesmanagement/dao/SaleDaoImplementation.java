package com.capgemini.salesmanagement.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.capgemini.bean.Sale;

public class SaleDaoImplementation implements ISaleDao{
	Map<Integer, Sale> map=new HashMap<>();
	@Override
	public boolean save(Sale sale) {
		//Map<Integer, Sale> map=new HashMap<>();
		if(map.containsKey(sale.getSaleId()))
			return false;
		else
			  map.put(sale.getSaleId(), sale);
		return true;
		//return (HashMap<Integer, Sale>) map;
	}
	public HashMap<Integer, Sale> insertDetails(Sale Sale)
	{
		for(Entry<Integer, Sale> entry:map.entrySet())
		{
			if(entry.getKey().equals(Sale.getSaleId()))
				 entry.getValue();
			return (HashMap<Integer, Sale>) map;
		}
		return null;
	}
	

}
