package com.capgemini.service;
import com.capgemini.bean.Category;
import com.capgemini.bean.Sale;
import com.capgemini.exception.InvalidPriceException;
import com.capgemini.exception.InvalidProductCategoryException;
import com.capgemini.exception.InvalidProductNameException;
import com.capgemini.exception.InvalidQuantityException;

public interface ISaleService {
public Sale insertDetails(Sale sale) throws InvalidQuantityException, InvalidProductCategoryException, InvalidPriceException;
//public boolean validateProductCode(int prodId);
public boolean validateQuantity(int qty) throws InvalidQuantityException;
public boolean validateProductCat(Category category) throws InvalidProductCategoryException;
public boolean validProductName(String ProdCat,String prodName) throws InvalidProductNameException;
public boolean validProductPrice(float price) throws InvalidPriceException;
}
