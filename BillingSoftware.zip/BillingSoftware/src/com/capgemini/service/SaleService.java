package com.capgemini.service;
import com.capgemini.bean.Category;
import com.capgemini.bean.Sale;
import com.capgemini.exception.InvalidPriceException;
import com.capgemini.exception.InvalidProductCategoryException;
import com.capgemini.exception.InvalidProductNameException;
import com.capgemini.exception.InvalidQuantityException;
import com.capgemini.salesmanagement.dao.ISaleDao;

public class SaleService implements ISaleService{
	ISaleDao isale;

	@Override
	public Sale insertDetails(Sale sale) throws InvalidQuantityException, InvalidProductCategoryException, InvalidPriceException {
		Sale sal=new Sale(sale.getSaleId(), sale.getProdCode(), sale.getCategory(), sale.getQuantity(), sale.getLineTotal());
		if(validateQuantity(sale.getQuantity()))
			if(validateProductCat(sale.getCategory()))
				if(validProductPrice(sale.getLineTotal()))
		//return sale;
		return sal;
		return null;
		
	}

//	@Override
//	public boolean validateProductCode(int prodId) {
//		
//		return false;
//	}

	public SaleService(ISaleDao isale) {
		super();
		this.isale = isale;
	}

	@Override
	public boolean validateQuantity(int qty) throws InvalidQuantityException {
		if(!(qty>2 && qty<5))
			throw new InvalidQuantityException();
		return false;
	}

	@Override
	public boolean validateProductCat(Category category) throws InvalidProductCategoryException {
		if(!(category.getProductName().equals("Electronics") || category.getProductName().equals("Toys")))
			throw new InvalidProductCategoryException();
		return false;
	}

	@Override
	public boolean validProductName(String prodCat,String prodName) throws InvalidProductNameException {
		//if(prodCat.equals("Electronics"))
if(!(prodName.equals("TV")||prodName.equals("Smart Phone")||prodName.equals("Video Name")||prodName.equals("SoftToy")||prodName.equals("Barbie Doll")))
		//else if(prodCat.equals("Toys"))
			throw new InvalidProductNameException();
return false;
				}

	@Override
	public boolean validProductPrice(float price) throws InvalidPriceException {
		if(price<200)
			throw new InvalidPriceException();
		return false;
	}

}
