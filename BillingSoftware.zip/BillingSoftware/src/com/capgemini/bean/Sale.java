package com.capgemini.bean;
public class Sale {
private int saleId;
 private int prodCode;
//private String productName;
private Category category;
private int quantity;
private float lineTotal;
public int getSaleId() {
	return saleId;
}
public void setSaleId(int saleId) {
	this.saleId = saleId;
}
public int getProdCode() {
	return prodCode;
}
public void setProdCode(int prodCode) {
	this.prodCode = prodCode;
}
public Category getCategory() {
	return category;
}
public void setCategory(Category category) {
	this.category = category;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public float getLineTotal() {
	return lineTotal;
}
public void setLineTotal(float lineTotal) {
	this.lineTotal = lineTotal;
}
public Sale(int saleId, int prodCode, Category category, int quantity, float lineTotal) {
	super();
	this.saleId = saleId;
	this.prodCode = prodCode;
	this.category = category;
	this.quantity = quantity;
	this.lineTotal = lineTotal;
}
@Override
public String toString() {
	return "Sale [saleId=" + saleId + ", prodCode=" + prodCode + ", category=" + category + ", quantity=" + quantity
			+ ", lineTotal=" + lineTotal + "]";
}


}
