package com.capgemini.bean;

public class Category {
private String productName;

public String getProductName() {
	return productName;
}

public void setProductName(String productName) {
	this.productName = productName;
}

@Override
public String toString() {
	return "Category [productName=" + productName + "]";
}

public Category(String productName) {
	super();
	this.productName = productName;
}

}
