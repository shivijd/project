package com.capgemini.exception;

public class InvalidProductCategoryException extends Exception {

}
