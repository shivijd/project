package com.capgemini.exception;

public class InvalidQuantityException extends Exception {

}
