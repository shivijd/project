package com.capgemini.exception;

public class InvalidProductNameException extends Exception{

}
