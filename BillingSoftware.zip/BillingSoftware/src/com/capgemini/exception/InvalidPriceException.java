package com.capgemini.exception;

public class InvalidPriceException extends Exception{

}
