package com.capgemini.main;

import java.util.Scanner;

import com.capgemini.bean.Category;
import com.capgemini.exception.InvalidPriceException;
import com.capgemini.exception.InvalidProductCategoryException;
import com.capgemini.exception.InvalidQuantityException;
import com.capgemini.salesmanagement.dao.ISaleDao;
import com.capgemini.salesmanagement.dao.SaleDaoImplementation;
import com.capgemini.service.ISaleService;
import com.capgemini.service.SaleService;

public class MainClass {
public static void main(String[]args) throws InvalidQuantityException, InvalidProductCategoryException, InvalidPriceException
{
	ISaleDao is=new SaleDaoImplementation();
	ISaleService iss=new SaleService(is);
	Scanner sc=new Scanner(System.in);
	int saleId=(int) (Math.random()*(100));
	System.out.println(saleId);
	int prodCode=sc.nextInt();
	String ProdCat=sc.next();
	Category category=new Category(ProdCat);
	category.setProductName(ProdCat);
	int quantity=sc.nextInt();
	int price=sc.nextInt();
	float lineTotal=quantity*price;
	System.out.println(iss.insertDetails(null));
}
}
